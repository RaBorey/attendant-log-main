<?php

namespace App\Http\Controllers\Mobile\V1;

use App\User;
use App\AttendantLog;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use App\Http\Resources\UserResource;
use Illuminate\Support\Facades\Hash;
use App\Http\Resources\AttendantLogResource;
use App\Http\Resources\AttendantLogCollection;
use App\Http\Controllers\Mobile\V1\APIsController;

class ProfileApiController extends APIsController
{

    /**
     * 
     */
    public function auth(Request $request) {
        $email = $request->{'email'};
        $password = $request->{'password'};

        $message = array();
        if (!isset($email) || $email == '') {
            $message[] = 'Email is required!';
        }
        if (!isset($password) || $password == '') {
            $message[] = 'Password is required!';
        }

        if (count($message) > 0) {
            return response()
                        ->json(['message' => $message, 'statusCode' => 422])
                        ->setStatusCode(200);
        }

        $user = User::where("email", $email)->first();
        if ($user) {
            if (Hash::check($password, $user->password, [])) {
                $resource = new UserResource($user);
                $resource->additional = ['token' => $this->createToken($user), 'message' => 'Success', 'statusCode' => 200];
                return $resource;
            }
        }
         return response()
                    ->json(['message' => 'Invalid identifier or phone', 'statusCode' => 401])
                    ->setStatusCode(200);
    }

    /**
     * 
     */
    private function createToken($user, $remember = true) {
        $tokenResult = $user->createToken('Mobile Access Token');
        $token = $tokenResult->token;
        $token->scopes = ['*'];
        if ($remember) {
            $token->expires_at = Carbon::now()->addYears(1);
        }
        $token->save();

        return [
                 'access_token' => $tokenResult->accessToken,
                'token_type' => 'Bearer',
                'expires_in' => Carbon::parse($tokenResult->token->expires_at)->toDateTimeString()
        ];
    }

    /**
     * 
     */
    public function logAttendant(Request $request) {
        $user = $this->getUserProfile($request);

        $att_date = Carbon::now();

        $att_clock_type = $request->{'att_clock_type'};
        $att_type = $request->{'att_type'};
        $att_latitude = $request->{'att_latitude'};
        $att_longtitude = $request->{'att_longtitude'};

        $message = array();
        if (!isset($att_date)) {
            $message[] = 'Date is required!';
        }
        if (!isset($att_clock_type) || $att_clock_type == '') {
            $message[] = 'Clock Type is required!';
        }
        if (!isset($att_type) || $att_type == '') {
            $message[] = 'Type is required!';
        }

        if (count($message) > 0) {
            return response()
                        ->json(['message' => $message, 'statusCode' => 422])
                        ->setStatusCode(200);
        }

        $attendantLog = new AttendantLog();
        $attendantLog->att_date = $att_date;
        $attendantLog->att_clock_type = $att_clock_type;
        $attendantLog->att_type = $att_type;
        $attendantLog->att_latitude = $att_latitude;
        $attendantLog->att_longtitude = $att_longtitude;
        $attendantLog->user_id = $user->id;
        $attendantLog->save();

        return response()
            ->json(['message' => 'Successfully', 'statusCode' => 200])
            ->setStatusCode(200);
    }

    /**
     * 
     */
    public function getAttendantLogs(Request $request) {
        $user = $this->getUserProfile($request);
        
        $pageSize = $request->query('pageSize', 10);
        $pageIndex = $request->query('pageIndex', 0);

        $attendantLogs = AttendantLog::with(['user'])->where("user_id", $user->id)->offset($pageIndex)->limit($pageSize)->get();
        return AttendantLogResource::collection($attendantLogs);
    }
}