<?php

namespace App\Http\Controllers\Mobile\V1;

use App\Http\Controllers\Controller;

class APIsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        echo "<!DOCTYPE html>
            <html lang=\"en\">
            <head>
            <meta charset=\"utf-8\">
            <title>API v1 | Restful Web Services</title>
            <body>
            <br>
            <div>
            Restful Web Services: <br>
            </div>
            </body>
            </html>
        ";
        exit();
    }

    public function getUserProfile($request) {
        return $request->user();
    }
}
