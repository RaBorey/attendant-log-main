<?php

namespace App\Http\Controllers\Api;

use App\AttendantLog;
use App\Http\Resources\AttendantLogResource;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class AttendantLogController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @param Request $request
     * @return AnonymousResourceCollection
     */
    public function index(Request $request) {
        $user = $request->user();
        if ($user &&  $user->role == 'admin') {
            $attendantLogs =  AttendantLog::with(['user'])->get();
        } else {
            $attendantLogs =  AttendantLog::with(['user'])->where("user_id", $user->id)->get();
        }
        return AttendantLogResource::collection(paginate($attendantLogs, $request->itemsPerPage, $request->page));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\AttendantLog  $attendantLog
     * @return \Illuminate\Http\Response
     */
    public function show(AttendantLog $attendantLog)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\AttendantLog  $attendantLog
     * @return \Illuminate\Http\Response
     */
    public function edit(AttendantLog $attendantLog)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\AttendantLog  $attendantLog
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, AttendantLog $attendantLog)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\AttendantLog  $attendantLog
     * @return \Illuminate\Http\Response
     */
    public function destroy(AttendantLog $attendantLog)
    {
        //
    }
}
