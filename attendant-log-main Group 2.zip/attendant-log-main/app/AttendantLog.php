<?php

namespace App;

use App\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class AttendantLog extends Model
{
    use HasFactory;

        /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'att_date', 'att_clock_type', 'att_type', 'user_id', 'att_latitude', 'att_longtitude'
    ];

    protected $appends = ['att_clock_type_text', 'att_type_text'];

    public function user()
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    public function getAttClockTypeTextAttribute() {
        if ($this->att_clock_type == 1) {
            return "IN";
        } else {
            return "OUT";
        }
    }

    public function getAttTypeTextAttribute() {
        if ($this->att_type == 1) {
            return "MORNING";
        } else if ($this->att_type == 2) {
            return "AFTERNOON";
        } else {
            return "EVENNING";
        }
    }
}
