<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAttendantLogsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('attendant_logs', function (Blueprint $table) {
            $table->id();
            $table->timestamps();
            $table->timestamp('att_date')->nullable();

            $table->integer('att_clock_type')->unsigned()->nullable(); // 1: IN, 2: OUT
            
            $table->integer('att_type')->unsigned()->nullable(); // 1: Morning, 2: Afternoon, 3: Evenning

            $table->integer('user_id')->unsigned()->nullable();
            $table->foreign('user_id')->references('id')->on('users')->onDelete('cascade');

            $table->string('att_latitude')->nullable();
            $table->string('att_longtitude')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('attendant_logs');
    }
}
