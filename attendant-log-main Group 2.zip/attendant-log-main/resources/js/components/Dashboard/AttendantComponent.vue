<template xmlns:v-slot="http://www.w3.org/1999/XSL/Transform">
    <div class="container">
        <!--Table View Started-->
        <material-card color="green" title="Attendants">
            <v-data-table :items="data" :headers="headers" :loading="loading" loading-text="Loading... Please wait" :options.sync="options" :server-items-length="totalData">
                <template v-slot:top>
                    <v-text-field @change="fetch" v-model="options.search" prepend-icon="search" label="Search ......" class="mx-4"> </v-text-field>
                </template>

                <template v-slot:item.role="{ item }">
                    <v-chip :color="item.role=='admin'?'teal':'blue'" dark>
                        {{item.role.charAt(0).toUpperCase()+item.role.slice(1) }}
                    </v-chip>
                </template>

                <template slot="no-data">
                    <v-alert :value="true" color="error" icon="warning">
                        Sorry, No Users Yet.
                    </v-alert>
                </template>
            </v-data-table>
        </material-card>
        
    </div>
</template>

<script>

    import {mapGetters} from 'vuex';

    export default {
        /*injecting the vee-validate*/
        inject: ['$validator'],

        data() {
            return {
                /*Data Table Related Variable*/
                loading: true,
                headers: [
                    {text: 'Date', value: 'att_date'},
                    {text: 'Name', align: 'left', sortable: false, value: 'user.name'},
                    {text: 'Clock Type', value: 'att_clock_type_text'},
                    {text: 'Type', value: 'att_type_text'},
                ],
                data: [],
                totalData: 0,

                /*Search and Query Related Variable*/
                options: {
                    page: 1,
                    itemsPerPage: 10,
                    search: undefined,
                    sort: 'desc'
                },

                /*Edit Dialog Related Variables*/
                dialog: false,
                valid: true,
                requiredRules: [
                    v => !!v || 'Required field'
                ],
                emailRules: [
                    v => !!v || 'E-mail is required',
                    v => /.+@.+/.test(v) || 'E-mail must be valid'
                ],
                usernameRules: [
                    v => !!v || 'Name is required',
                    v => (v && v.length >= 6) || 'Profilename can\'t be less than 6 characters'
                ],
                editedIndex: -1,
                editedItem: {
                    name: '',
                    email: '',
                    role: '',
                },
                defaultItem: {
                    name: '',
                    email: '',
                    role: '',
                },
                path: JSON.parse(JSON.stringify(this.$route.path))
            }
        }, computed: {
            ...mapGetters([]),
            getFullPath () {
                return this.$route.path
            }
        },
        watch: {
            options: {
                handler() {
                    this.fetch();
                },
                deep: true,
            },
            dialog(val) {
                val || this.close()
            },
            getFullPath () {
                if(this.getFullPath === this.path){
                    this.fetch()
                }
            }

        },

        methods: {
            /*Fetch Users*/
            fetch() {
                return new Promise((resolve, reject) => {
                    this.$store.dispatch('fetchAttendants', this.options)
                        .then(response => {
                            this.data = response.data.data;
                            this.loading = false;
                            this.totalData = response.data.meta.total;
                        }).catch(error => {
                        // console.log(error.response.status);
                    });
                })

            },
        },
    }
</script>
