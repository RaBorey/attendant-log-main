<template>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <material-card
                    color="green"
                    :title="'Welcome,  '+getProfile.name"
                >
                    <div class="card-body">
                            <table style="width:100%">
                                <tr>
                                    <td style="text-align: center;">Clock IN</td>
                                    <td style="with:20%">&nbsp;</td>
                                    <td style="text-align: center;">Clock OUT</td>
                                </tr>
                                <tr>
                                    <td><v-img :src="qrin" height="400" contain/></td>
                                    <td>&nbsp;</td>
                                    <td><v-img :src="qrout" height="400" contain/></td>
                                </tr>
                            </table>
                            
                    </div>
                </material-card>
            </div>
        </div>
    </div>
</template>

<script>
    import {mapGetters} from 'vuex';

    export default {
        data() {
            return {
                qrin: '/images/QR_MORNING_IN.png',
                qrout: '/images/QR_MORNING_out.png',
                sidebar: '/images/sidebar.png'
            }
        },
        computed: {
            ...mapGetters([
                'getProfile'
            ])
        },
        mounted() {

        },
    }
</script>
