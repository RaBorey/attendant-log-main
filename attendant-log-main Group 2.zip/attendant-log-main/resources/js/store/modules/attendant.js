import axios from 'axios';

export default {
    state: {
        attendants: [],
        user: {},
    },
    mutations: {
        setUser(state, payload) {
            state.user = payload
        },
        setAttendants(state, payload) {
            state.attendants = payload;
        },
        setUserId(state, payload) {
            state.user.id = payload
        },

    },
    actions: {
        fetchUser({ commit, state, rootState }, payload) {
            return new Promise(((resolve, reject) => {
                commit('setLoading', true);
                axios.get('/attendants/' + payload)
                    .then(response => {
                        commit('setLoading', false)
                        commit('setUser', response.data)
                        resolve(response)
                    })
                    .catch(error => {
                        commit('setLoading', false);
                        reject(error)
                    })

            }))

        },
        fetchAttendants({ commit, state, rootState }, payload) {
            return new Promise(((resolve, reject) => {
                commit('setLoading', true);
                axios.get('/get-attendants', { params: payload })
                    .then(response => {
                        commit('setLoading', false)
                        commit('setAttendants', response.data.data)
                        resolve(response)

                    })
                    .catch(error => {
                        commit('setLoading', false);
                        reject(error)
                    })

            }))

        },

        setUser({ commit, state }, payload) {
            commit('setUser', payload);
        },
        clearUser({ commit }) {
            commit('setUser', {})
        },

    },
    getters: {
        getUser: state => {
            return state.user;
        },
        getAttendants: state => {
            return state.attendants;
        }
    }
}
